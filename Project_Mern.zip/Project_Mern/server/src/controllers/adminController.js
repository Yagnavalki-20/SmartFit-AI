const User = require("../models/User");
const Order = require("../models/Order");
const { sendEmail } = require("../services/emailService");

const getPendingUsers = async (_req, res) => {
  const users = await User.find({ role: "user", isEmailVerified: true, isApproved: false }).select(
    "name email phone createdAt"
  );
  return res.json(users);
};

const approveUser = async (req, res) => {
  const { userId } = req.params;
  const user = await User.findById(userId);

  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }

  user.isApproved = true;
  await user.save();

  await sendEmail({
    to: user.email,
    subject: "Account approved",
    html: `<p>Hello ${user.name}, your account is approved by admin. You can now login and shop.</p>`
  });

  return res.json({ message: "User approved" });
};

const getAllOrders = async (_req, res) => {
  const orders = await Order.find().populate("user", "name email").sort({ createdAt: -1 });
  return res.json(orders);
};

module.exports = { getPendingUsers, approveUser, getAllOrders };
