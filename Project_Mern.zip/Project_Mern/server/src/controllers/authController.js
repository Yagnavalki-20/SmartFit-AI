const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { validationResult } = require("express-validator");
const User = require("../models/User");
const generateToken = require("../utils/generateToken");
const { sendEmail } = require("../services/emailService");

const signup = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ message: "Validation failed", errors: errors.array() });
  }

  const { name, email, password, phone } = req.body;

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      phone,
      isEmailVerified: false,
      isApproved: false
    });

    const emailToken = jwt.sign({ id: user._id, action: "verify-email" }, process.env.JWT_SECRET, {
      expiresIn: "1d"
    });

    const verificationLink = `${process.env.SERVER_BASE_URL}/api/auth/verify-email?token=${emailToken}`;

    await sendEmail({
      to: user.email,
      subject: "Verify your account",
      html: `<p>Hello ${user.name},</p><p>Please verify your email by clicking <a href="${verificationLink}">this link</a>.</p>`
    });

    return res.status(201).json({
      message: "Account created. Please verify your email, then wait for admin approval."
    });
  } catch (error) {
    return res.status(500).json({ message: "Signup failed", error: error.message });
  }
};

const verifyEmail = async (req, res) => {
  try {
    const { token } = req.query;
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.action !== "verify-email") {
      return res.status(400).json({ message: "Invalid verification token" });
    }

    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    user.isEmailVerified = true;
    await user.save();

    return res.json({ message: "Email verified. Waiting for admin approval." });
  } catch (error) {
    return res.status(400).json({ message: "Verification failed", error: error.message });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    if (!user.isEmailVerified) {
      return res.status(403).json({ message: "Please verify email before login" });
    }

    if (!user.isApproved) {
      return res.status(403).json({ message: "Admin approval pending" });
    }

    const token = generateToken({ id: user._id, role: user.role });

    return res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role
      }
    });
  } catch (error) {
    return res.status(500).json({ message: "Login failed", error: error.message });
  }
};

const me = async (req, res) => {
  return res.json({ user: req.user });
};

module.exports = { signup, login, verifyEmail, me };
