const Order = require("../models/Order");
const User = require("../models/User");
const { sendSMS } = require("../services/smsService");

const addAddress = async (req, res) => {
  const user = await User.findById(req.user._id);
  user.addresses.push(req.body);
  await user.save();

  return res.status(201).json(user.addresses);
};

const getAddresses = async (req, res) => {
  const user = await User.findById(req.user._id);
  return res.json(user.addresses);
};

const placeOrder = async (req, res) => {
  const { addressId, paymentMethod } = req.body;

  if (!["COD", "ONLINE"].includes(paymentMethod)) {
    return res.status(400).json({ message: "Invalid payment method" });
  }

  const user = await User.findById(req.user._id).populate("cart.product");

  if (!user.cart.length) {
    return res.status(400).json({ message: "Cart is empty" });
  }

  const address = user.addresses.id(addressId);
  if (!address) {
    return res.status(404).json({ message: "Address not found" });
  }

  const items = user.cart.map((item) => ({
    product: item.product._id,
    name: item.product.name,
    price: item.product.price,
    quantity: item.quantity
  }));

  const totalAmount = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const expectedDeliveryDate = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000);

  const order = await Order.create({
    user: user._id,
    items,
    shippingAddress: address.toObject(),
    paymentMethod,
    paymentStatus: paymentMethod === "ONLINE" ? "PENDING" : "PENDING",
    totalAmount,
    expectedDeliveryDate
  });

  user.cart = [];
  await user.save();

  await sendSMS({
    phone: user.phone,
    message: `Order ${order._id} placed. Amount: ${totalAmount}. Delivery by ${expectedDeliveryDate.toDateString()}.`
  });

  return res.status(201).json(order);
};

const getMyOrders = async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
  return res.json(orders);
};

module.exports = { addAddress, getAddresses, placeOrder, getMyOrders };
