const User = require("../models/User");
const Product = require("../models/Product");

const getCart = async (req, res) => {
  const user = await User.findById(req.user._id).populate("cart.product");
  return res.json(user.cart);
};

const addToCart = async (req, res) => {
  const { productId, quantity = 1 } = req.body;

  const product = await Product.findById(productId);
  if (!product) {
    return res.status(404).json({ message: "Product not found" });
  }

  const user = await User.findById(req.user._id);
  const existingItem = user.cart.find((item) => item.product.toString() === productId);

  if (existingItem) {
    existingItem.quantity += Number(quantity);
  } else {
    user.cart.push({ product: productId, quantity: Number(quantity) });
  }

  await user.save();
  const updatedUser = await User.findById(req.user._id).populate("cart.product");
  return res.json(updatedUser.cart);
};

const removeFromCart = async (req, res) => {
  const { productId } = req.params;

  const user = await User.findById(req.user._id);
  user.cart = user.cart.filter((item) => item.product.toString() !== productId);
  await user.save();

  const updatedUser = await User.findById(req.user._id).populate("cart.product");
  return res.json(updatedUser.cart);
};

module.exports = { getCart, addToCart, removeFromCart };
