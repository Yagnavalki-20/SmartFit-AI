const sendSMS = async ({ phone, message }) => {
  if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_FROM_PHONE) {
    console.log("SMS skipped because Twilio is not configured", { phone, message });
    return;
  }

  const twilio = require("twilio");
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

  await client.messages.create({
    body: message,
    from: process.env.TWILIO_FROM_PHONE,
    to: phone
  });
};

module.exports = { sendSMS };
