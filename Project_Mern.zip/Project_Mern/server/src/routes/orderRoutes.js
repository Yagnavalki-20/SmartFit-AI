const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const { addAddress, getAddresses, placeOrder, getMyOrders } = require("../controllers/orderController");

const router = express.Router();

router.get("/addresses", protect, getAddresses);
router.post("/addresses", protect, addAddress);
router.post("/", protect, placeOrder);
router.get("/my", protect, getMyOrders);

module.exports = router;
