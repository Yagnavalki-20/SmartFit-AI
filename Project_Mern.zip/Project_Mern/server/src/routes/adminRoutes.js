const express = require("express");
const { protect, adminOnly } = require("../middleware/authMiddleware");
const { getPendingUsers, approveUser, getAllOrders } = require("../controllers/adminController");

const router = express.Router();

router.get("/pending-users", protect, adminOnly, getPendingUsers);
router.patch("/approve-user/:userId", protect, adminOnly, approveUser);
router.get("/orders", protect, adminOnly, getAllOrders);

module.exports = router;
