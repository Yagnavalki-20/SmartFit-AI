const express = require("express");
const { body } = require("express-validator");
const { signup, login, verifyEmail, me } = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.post(
  "/signup",
  [
    body("name").notEmpty(),
    body("email").isEmail(),
    body("phone").notEmpty(),
    body("password").isLength({ min: 6 })
  ],
  signup
);
router.post("/login", login);
router.get("/verify-email", verifyEmail);
router.get("/me", protect, me);

module.exports = router;
