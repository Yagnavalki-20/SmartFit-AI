# MERN Online Shopping Platform

A full-stack MERN starter platform implementing your requested workflow:

- User registration
- Email verification link
- Admin approval before login access
- Product browsing and cart
- Address management
- Checkout with COD or Online Payment selection
- Order record with expected delivery date
- SMS order notification to user phone number

## Tech Stack

- Frontend: React + Vite + Axios + React Router
- Backend: Node.js + Express + MongoDB + Mongoose
- Auth: JWT
- Email: Nodemailer (SMTP)
- SMS: Twilio

## Project Structure

- client: React frontend
- server: Node/Express API
- package.json (root): helper scripts to run both

## Backend Environment Setup

1. Copy server/.env.example to server/.env
2. Fill these required values:

- MONGO_URI
- JWT_SECRET
- CLIENT_BASE_URL
- SERVER_BASE_URL

3. Optional but recommended for full flow:

- SMTP_HOST
- SMTP_PORT
- SMTP_USER
- SMTP_PASS
- SMTP_FROM
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_FROM_PHONE

If SMTP or Twilio are not configured, the app will log notifications in server console instead of failing.

## Run Locally

1. Install dependencies in root, server, and client (already done once during setup).
2. Start full stack from root:

npm run dev

This runs:

- server on http://localhost:5000
- client on http://localhost:5173

## Seed First Admin

Create admin user before approving customers:

1. Add ADMIN_EMAIL and ADMIN_PASSWORD into server/.env (optional)
2. Run:

npm run seed-admin --prefix server

Default admin credentials if env not provided:

- email: admin@shop.com
- password: admin123

## API Overview

### Auth

- POST /api/auth/signup
- GET /api/auth/verify-email?token=...
- POST /api/auth/login
- GET /api/auth/me

### Products

- GET /api/products
- POST /api/products (admin)

### Cart

- GET /api/cart
- POST /api/cart
- DELETE /api/cart/:productId

### Orders and Address

- GET /api/orders/addresses
- POST /api/orders/addresses
- POST /api/orders
- GET /api/orders/my

### Admin

- GET /api/admin/pending-users
- PATCH /api/admin/approve-user/:userId
- GET /api/admin/orders

## End-to-End User Flow

1. User signs up with name, email, phone, password.
2. User receives verification email.
3. User clicks verify link.
4. Admin logs in and approves pending verified users.
5. User can now login.
6. User browses products, adds to cart.
7. User adds shipping address.
8. User chooses payment method (COD or ONLINE) and places order.
9. System stores order with expected delivery date (currently 5 days from order).
10. System sends SMS with order details and expected delivery date.

## Important Notes

- ONLINE payment is currently modeled as method selection and status tracking (PENDING/PAID). Payment gateway integration can be added next (Razorpay/Stripe).
- For production, add proper validation, rate limiting, logging, and secure secrets management.
- Use HTTPS in production for email verification URLs and API security.
